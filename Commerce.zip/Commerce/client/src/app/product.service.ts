import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Product } from './product';
import { NewProduct } from './product-new';

@Injectable()
export class ProductService {

  constructor(
    private _http: Http
  ) { }

  index(callback) {
    this._http.get('/products').subscribe(
      res => callback(res.json()),
      err => console.log(err)
    );
  }

  create(newPoll: NewProduct, callback) {
    this._http.post('/products', newPoll).subscribe(
      res => callback(res.json()),
      err => console.log(err)
    );
  }

  show(id: string, callback) {
    this._http.get(`/products/${id}`).subscribe(
      res => callback(res.json()),
      err => console.log(err)
    );
  }

  destroy(id: string, callback) {
    this._http.delete(`/products/${id}`).subscribe(
      res => callback(res.json()),
      err => console.log(err)
    );
  }

}

