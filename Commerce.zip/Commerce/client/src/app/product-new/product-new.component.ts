import { Component, OnInit } from '@angular/core';
import { NewProduct } from '../new-product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-new',
  templateUrl: './product-new.component.html',
  styleUrls: ['./product-new.component.css']
})
export class ProductNewComponent implements OnInit {


  newProduct: NewProduct = new NewProduct();
  errors: string[] = [];

  constructor(
    private _productService: ProductService,
    private _router: Router
  ) { }

  ngOnInit() {
  }

  createProducts() {
    // console.log(this.newPoll);
    this.errors = [];
    if(this.newProduct.option1.option.length < 3){
      this.errors.push('Product must have a name.')
    }
    this._productService.create(this.newProduct, (product) => {
      if (product.errors) {
        for (const key of Object.keys(product.errors)) {
          const error = product.errors[key];
          this.errors.push(error.message);
        }
      } else {
        this._router.navigateByUrl('/product');
      }
    });
  }

}