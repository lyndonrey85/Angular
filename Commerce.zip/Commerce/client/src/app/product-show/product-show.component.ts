import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poll-show',
  templateUrl: './poll-show.component.html',
  styleUrls: ['./poll-show.component.css']
})
export class PollShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}