import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Poll } from '../product';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any;
  _productService: any;
  getProducts(): any {
    throw new Error("Method not implemented.");
  }

  polls: Poll[];

  constructor(
    private _router: Router,
    private _pollService: ProductService
  ) { }

  ngOnInit() {
    this.getProducts();
  }

  destroyProduct(id: string) {
    this._productService.destroy(id, (res) => {
      if(res.status === true) {
        this.getProducts();
      }
    });
  }

  getProducts() {
    this._productService.index((products) => this.products = products)
  }

}
